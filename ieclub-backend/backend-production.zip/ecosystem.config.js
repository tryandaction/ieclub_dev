// ecosystem.config.js
// PM2 进程管理配置文件（企业级）

module.exports = {
  apps: [
    {
      name: 'ieclub-api',
      script: './src/index.js',
      instances: 'max', // 使用所有CPU核心
      exec_mode: 'cluster', // 集群模式
      
      // 环境配置
      env: {
        NODE_ENV: 'development',
        PORT: 3000
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000
      },
      env_staging: {
        NODE_ENV: 'staging',
        PORT: 3000
      },
      
      // 自动重启配置
      watch: false, // 生产环境不监听文件变化
      ignore_watch: ['node_modules', 'logs', 'uploads', '.git'],
      max_memory_restart: '1G', // 内存超过1G时重启
      
      // 日志配置
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      error_file: './logs/pm2-error.log',
      out_file: './logs/pm2-out.log',
      log_file: './logs/pm2-combined.log',
      merge_logs: true,
      
      // 性能优化
      max_restarts: 10, // 最大重启次数
      min_uptime: '10s', // 最小运行时间
      listen_timeout: 3000, // 监听超时时间
      kill_timeout: 5000, // 停止超时时间
      
      // 健康检查
      wait_ready: true,
      
      // 优雅关闭
      shutdown_with_message: true,
      
      // 实例配置
      instance_var: 'INSTANCE_ID',
      
      // 自动重启策略
      autorestart: true,
      cron_restart: '0 3 * * *', // 每天凌晨3点重启（避开高峰期）
      
      // Exponential backoff restart delay
      exp_backoff_restart_delay: 100,
      
      // 错误日志
      combine_logs: true,
      
      // 时区
      time: true
    },
    
    // 定时任务进程（可选）
    {
      name: 'ieclub-cron',
      script: './src/jobs/index.js',
      instances: 1,
      exec_mode: 'fork',
      cron_restart: '0 0 * * *', // 每天午夜重启
      
      env: {
        NODE_ENV: 'development'
      },
      env_production: {
        NODE_ENV: 'production'
      },
      
      error_file: './logs/cron-error.log',
      out_file: './logs/cron-out.log',
      merge_logs: true
    }
  ],
  
  // 部署配置
  deploy: {
    production: {
      user: 'deploy',
      host: ['ieclub.online'],
      ref: 'origin/main',
      repo: 'git@github.com:yourusername/ieclub.git',
      path: '/var/www/ieclub',
      'pre-deploy-local': '',
      'post-deploy': 'npm install && npx prisma migrate deploy && pm2 reload ecosystem.config.js --env production',
      'pre-setup': '',
      ssh_options: 'StrictHostKeyChecking=no'
    },
    
    staging: {
      user: 'deploy',
      host: ['staging.ieclub.online'],
      ref: 'origin/develop',
      repo: 'git@github.com:yourusername/ieclub.git',
      path: '/var/www/ieclub-staging',
      'post-deploy': 'npm install && npx prisma migrate deploy && pm2 reload ecosystem.config.js --env staging',
      ssh_options: 'StrictHostKeyChecking=no'
    }
  }
};

